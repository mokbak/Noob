class GoogleError(Exception):
    pass
