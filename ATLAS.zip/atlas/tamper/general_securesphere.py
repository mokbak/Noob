#!/usr/bin/env python
# -*- coding:utf-8 -*-

def general_securesphere(payload):
	# -- general -- 
	return payload + " and '0having'='0having'" if payload else payload